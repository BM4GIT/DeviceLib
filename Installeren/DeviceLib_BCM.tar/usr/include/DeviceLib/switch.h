// file:   switch.h
// author: D.E.Veloper
// date:   2020-01-01

#ifndef SWITCH_H
#define SWITCH_H

#include "sensor.h"

#define GND 0
#define VCC 1

class Switch : public Sensor
{
public:

    Switch();
    ~Switch();

    void setPin( uint8_t pin, uint8_t connect);
    void setNormalOpen( bool normalopen);
    void triggerEvent( void (*callback)());

    void read();

    bool pressed();
    bool released();
    bool changed();

private:

    int8_t	m_pin;
    uint8_t m_conn;
    bool	m_normalopen;
    bool	m_pressed;
    bool    m_changed;
};

#endif // SWITCH_H
