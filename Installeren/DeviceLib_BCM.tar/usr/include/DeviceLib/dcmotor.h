// file:   dcmotor.h
// author: D.E.Veloper
// date:   2020-01-01

#ifndef DCMOTOR_H
#define DCMOTOR_H

#include "actuator.h"

#define FULLSPEED 100

class DcMotor : public Actuator
{
public:
    DcMotor();
    ~DcMotor();

    void setPin( uint8_t pin, bool pwm = true);

    void setSpeed( uint8_t speed);
    void setOn();
    void setOff();

protected:
    int8_t   m_pin;
    uint8_t  m_speed;
    bool     m_pwm;
};

#endif // DCMOTOR_H
