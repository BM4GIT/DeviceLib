// Arduino.h

#ifndef ARDUINO_H
#define ARDUINO_H

#include "ArduinoString.h"
#include "ArduinoCore.h"

#endif // ARDUINO_H
