// file:   distance.h
// author: D.E.Veloper
// date:   2020-01-01

#ifndef HCSR04_H
#define HCSR04_H

#include "sensor.h"

namespace HCSR04
{

class Average
{
public:
    Average();

    void  add( float value);
    void  clear();
    float avg();

protected:
    float  m_val[20];
    int    m_cur;
    bool   m_complete;
};

class Distance : public Sensor
{
public:
    Distance();
    ~Distance();

    void setPin( uint8_t trigger, uint8_t echo);

    void read();

    uint16_t cm();
    uint16_t inch();

private:
    int8_t     m_trigger;
	int8_t		m_echo;
    int8_t     m_cm;
};

} // end namespace

#endif // DISTANCE_H
