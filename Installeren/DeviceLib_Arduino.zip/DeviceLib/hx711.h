// file:	hx711.cpp

#ifndef HX711_H_
#define HX711_H_

#include "sensor.h"

namespace HX711 {

class Scale : public Sensor
{
public:

    Scale();
    ~Scale();

    void setPin( uint8_t pinClk, uint8_t pinOut);

    void read();

    uint16_t kg();

private:

    long getValue();
    long averageValue( uint8_t times = 25);
    void calibrate( long rawvalue);
    void setScale( float scale = 1992.f);

    int8_t m_clk;
    int8_t m_out;
    int8_t m_kg;

    long   m_value;
    long   m_zero;
    float  m_scale;
};

} // end namespace

#endif /* HX711_H_ */
