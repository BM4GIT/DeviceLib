// file:   sound.h
// author: D.E.Veloper
// date:   2020-01-01

#ifndef SOUND_H
#define SOUND_H

#ifndef RPI
#error NOTE: You cannot use 'sound.h' on Arduino
#else

#include "actuator.h"
#include "linkedlist.h"

class Sound : public Actuator
{
public:
    enum Streamer { Local, HDMI, Bluetooth };

    Sound() { m_streamer = Local; };
    ~Sound() {};

    void init( Streamer streamer, String device = "");

    uint8_t add( String sound, bool astext = false);
    void insert( uint8_t pos, String sound, bool astext = false);
    void remove( uint8_t pos, uint8_t count = 1);
    void clear();

    void playList();                // plays the list
    void playFile( String path);    // calls 'aplay' to play the file
    void playText( String text);    // calls 'espeak' to say the text

protected:

    LinkedList<String>  m_item; // audio-file or spoken text
    LinkedList<uint8_t> m_type; // 0 = audio-file, 1 = spoken text
    Streamer    m_streamer;
    String      m_device;
};

#endif // RPI

#endif // Sound_H
