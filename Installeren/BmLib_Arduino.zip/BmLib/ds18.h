// file:   dst.h
// author: D.E.Veloper
// date:   2020-01-01

#ifndef DS18_H
#define DS18_H

// Max sample rate Dallas w1 sensor is 1.3 Hz (duty cycle 750 ms)

#include "sensor.h"
#include "linkedlist.h"
//#ifdef RPI
//#include <vector>
//#endif

namespace DS18
{

typedef LinkedList<String> StringList;

class Temperature : public Sensor
{
public:

	Temperature();
	~Temperature() {};

    static StringList getIdList( uint8_t pin = 10);
    void setSensor( String id, uint8_t pin = 10);

    void read();

    float kelvin();
    float celcius();
    float fahrenheit();

private:

#ifdef RPI
    String  m_id;
#else
    int     m_id;
#endif
    int8_t m_pin;
    float   m_temp;
};

} // end namespace

#endif
